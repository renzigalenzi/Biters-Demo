﻿using UnityEngine;
using System.Collections;

public class QuitButton : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	} // end Start
	
	public void OnClick() {

		Application.Quit (); 

	} // end OnClick


} // end Quit Button
